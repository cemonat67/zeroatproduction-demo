/**
 * Fibre config (schema=zero).
 * Uses SUPABASE_URL + SUPABASE_ANON_KEY already defined in supabase.fabric.config.js
 */
window.SUPABASE_SCHEMA = "zero";
