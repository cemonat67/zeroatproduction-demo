/**
 * LOCAL CONFIG — do not commit secrets.
 * Use anon key only (safe for frontend). NEVER use service_role in browser.
 */
window.SUPABASE_URL = "https://rtwhzicuugebbxcpvstz.supabase.co";
window.SUPABASE_ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJ0d2h6aWN1dWdlYmJ4Y3B2c3R6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjIzODUwNjUsImV4cCI6MjA3Nzk2MTA2NX0.56QW4LvsQbys8meOA2dBwhpB8N7HH6Lm-YrZDEP687o";
window.SUPABASE_SCHEMA = "public"; // using public schema
